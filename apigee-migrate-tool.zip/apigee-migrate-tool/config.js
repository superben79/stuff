module.exports = {

	from: {
		version: '14.01',
		url: 'https://api.enterprise.apigee.com',
		userid: 'sbagdadi@apigee.com',
		passwd: 'shanu999',
		org: 'shah-nonprod',
		env: 'prod'
	},
	to: {
		version: '15.01',
		url: 'https://api.enterprise.apigee.com',
		userid: 'sbagdadi@apigee.com',
		passwd: 'shanu999',
		org: 'shah-prod',
		env: 'vm5'
	}
} ;
